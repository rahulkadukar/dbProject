
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema valve
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `valve` DEFAULT CHARACTER SET latin1 ;
USE `valve` ;

-- -----------------------------------------------------
-- Table `valve`.`valve_app_master`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`valve_app_master` (
  `appID` INT(11) NOT NULL,
  `lastUpdate` BIGINT(20) NOT NULL,
  PRIMARY KEY (`appID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `valve`.`game_description`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`game_description` (
  `appID` INT(11) NOT NULL,
  `description` VARCHAR(25000) NOT NULL,
  PRIMARY KEY (`appID`),
  CONSTRAINT `fkgamedescription`
    FOREIGN KEY (`appID`)
    REFERENCES `valve`.`valve_app_master` (`appID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkgamedescription_idx` ON `valve`.`game_description` (`appID` ASC);


-- -----------------------------------------------------
-- Table `valve`.`game_developers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`game_developers` (
  `appID` INT(11) NOT NULL,
  `developer` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`appID`, `developer`),
  CONSTRAINT `fkgamedeveloper`
    FOREIGN KEY (`appID`)
    REFERENCES `valve`.`valve_app_master` (`appID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkgamedeveloper_idx` ON `valve`.`game_developers` (`appID` ASC);


-- -----------------------------------------------------
-- Table `valve`.`game_genres`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`game_genres` (
  `appID` INT(11) NOT NULL,
  `genre` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`appID`, `genre`),
  CONSTRAINT `fkgamegenreappid`
    FOREIGN KEY (`appID`)
    REFERENCES `valve`.`valve_app_master` (`appID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkgamegenreappid_idx` ON `valve`.`game_genres` (`appID` ASC);


-- -----------------------------------------------------
-- Table `valve`.`game_master`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`game_master` (
  `appID` INT(11) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `metacritic` INT(11) NOT NULL,
  `currency` VARCHAR(10) NOT NULL,
  `price` INT(11) NOT NULL,
  `recommendation` INT(11) NOT NULL,
  `age` INT(11) NOT NULL,
  `achievements` INT(11) NOT NULL,
  `website` VARCHAR(255) NOT NULL,
  `releaseDate` VARCHAR(25) NOT NULL,
  CONSTRAINT `fkgamedescription`
    FOREIGN KEY (`appID`)
    REFERENCES `valve`.`valve_app_master` (`appID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkgamedescription_idx` ON `valve`.`game_master` (`appID` ASC);


-- -----------------------------------------------------
-- Table `valve`.`game_publishers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`game_publishers` (
  `appID` INT(11) NOT NULL,
  `publisher` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`appID`, `publisher`),
  CONSTRAINT `fkgamepublisherappid`
    FOREIGN KEY (`appID`)
    REFERENCES `valve`.`valve_app_master` (`appID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkgamepublisherappid_idx` ON `valve`.`game_publishers` (`appID` ASC);


-- -----------------------------------------------------
-- Table `valve`.`user_master`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`user_master` (
  `steamID` BIGINT(20) NOT NULL,
  `lastUpdate` BIGINT(20) NOT NULL,
  PRIMARY KEY (`steamID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `valve`.`user_data`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`user_data` (
  `steamID` BIGINT(20) NOT NULL,
  `realname` VARCHAR(255) NOT NULL,
  `personaname` VARCHAR(255) NOT NULL,
  `location` VARCHAR(10) NOT NULL,
  `profileurl` VARCHAR(255) NOT NULL,
  `timecreated` BIGINT(20) NOT NULL,
  `avatarfull` VARCHAR(255) NOT NULL,
  `type` INT(11) NOT NULL,
  PRIMARY KEY (`steamID`),
  CONSTRAINT `fkuserdata`
    FOREIGN KEY (`steamID`)
    REFERENCES `valve`.`user_master` (`steamID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `valve`.`user_friends`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`user_friends` (
  `steamID` BIGINT(20) NOT NULL,
  `friendID` BIGINT(20) NOT NULL,
  `friendSince` BIGINT(20) NOT NULL,
  PRIMARY KEY (`steamID`, `friendID`),
  CONSTRAINT `fkuserfriendssteaid`
    FOREIGN KEY (`steamID`)
    REFERENCES `valve`.`user_master` (`steamID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkuserfriendsfriendis`
    FOREIGN KEY (`friendID`)
    REFERENCES `valve`.`user_master` (`steamID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkuserfriendsfriendis_idx` ON `valve`.`user_friends` (`friendID` ASC);


-- -----------------------------------------------------
-- Table `valve`.`user_games`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `valve`.`user_games` (
  `steamID` BIGINT(20) NOT NULL,
  `appID` INT(11) NOT NULL,
  `playtime` INT(11) NOT NULL,
  PRIMARY KEY (`steamID`, `appID`),
  CONSTRAINT `fkusergamessteaid`
    FOREIGN KEY (`steamID`)
    REFERENCES `valve`.`user_master` (`steamID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkusergamesappid`
    FOREIGN KEY (`appID`)
    REFERENCES `valve`.`valve_app_master` (`appID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `fkusergamesappid_idx` ON `valve`.`user_games` (`appID` ASC);


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
